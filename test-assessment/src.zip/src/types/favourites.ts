export interface AddFavouriteViewModel {
    image_id: string;
    sub_id: string;
}

export interface FavouriteViewModel {
    id: string;
}

export interface FavouriteDto {
    id: number;     
    user_id?: string;  
    image_id: string;
    created_at: string;
}