import { useGlobal } from "@/composables/useGlobal";
import { baseApi } from "@/api/base";
import type { AddFavouriteViewModel } from "@/types/favourites";
import type { VoteDto } from "@/types/vote";
import type { AxiosResponse } from "axios";
const { subId } = useGlobal();

class ListingApi {

    getAllCats(): Promise<any> {
        return baseApi.get(`/images?limit=20&sub_id=${subId}`);
    }

    addToFavourites(imageId: string): Promise<any> {
        return baseApi.post<AddFavouriteViewModel>(`/favourites`, {
            image_id: imageId,
            sub_id: subId,
        });
    }

    removeFromFavourites(favouriteId: number): Promise<any> {
        return baseApi.delete(`/favourites/${favouriteId}`);
    }

    getFavourites(): Promise<any> {
        return baseApi.get(`/favourites?sub_id=${subId}`);
    }

    getVotesByImage(imageId: string): Promise<AxiosResponse<VoteDto[]>> {
        return baseApi.get<VoteDto[]>(`/votes?image_id=${imageId}`)
    }

    voteImage(imageId: string, value: 1|0): Promise<AxiosResponse<VoteDto>> {
        return baseApi.post<VoteDto>('/votes', {
            image_id: imageId,
            sub_id: subId,
            value: value,
        })
    }

    updateVote(voteId: number, value: 0 | 1): Promise<AxiosResponse<VoteDto>> {
        return baseApi.post<VoteDto>(`/votes/${voteId}`, { value })
    }
}

export default new ListingApi();
