interface ListItemVotingProps {
  score: number
  loading: boolean
  onUpvote: () => void
  onDownvote: () => void
}

export default function ListItemVoting({ score, loading, onUpvote, onDownvote }: ListItemVotingProps) {
  return (
    <div className="flex items-center space-x-3">
      <span className="text-sm text-gray-600">Score: {score}</span>

      <button
        onClick={onUpvote}
        disabled={loading}
        className={`px-3 py-1 rounded transition duration-150 ease-in-out \
          bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 \
          disabled:bg-gray-400 disabled:cursor-not-allowed disabled:opacity-50 text-white text-sm`}
      >
        {loading ? '...' : '👍'}
      </button>

      <button
        onClick={onDownvote}
        disabled={loading}
        className={`px-3 py-1 rounded transition duration-150 ease-in-out \
          bg-red-600 hover:bg-red-500 active:bg-red-700 \
          disabled:bg-gray-400 disabled:cursor-not-allowed disabled:opacity-50 text-white text-sm`}
      >
        {loading ? '...' : '👎'}
      </button>
    </div>
  )
}