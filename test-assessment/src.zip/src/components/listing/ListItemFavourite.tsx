interface ListItemFavouriteProps {
  isFavourite: boolean
  loading: boolean
  onToggleFavourite: () => void
}

export default function ListItemFavourite({ isFavourite, loading, onToggleFavourite }: ListItemFavouriteProps) {
  return (
    <button
      onClick={onToggleFavourite}
      disabled={loading}
      className={`
        flex items-center px-4 py-1 text-sm rounded transition duration-150 ' / 
        'ease-in-out bg-blue-700 hover:bg-blue-500 active:bg-blue-700 ' / 
        'disabled:bg-gray-400 disabled:cursor-not-allowed disabled:opacity-50 text-white`}
    >
      {loading 
        ? '...'
        : isFavourite 
          ? '★' 
          : '☆'}
          
      <span className="sr-only">{loading 
        ? '...'
        : isFavourite 
          ? 'Remove from Favourites' 
          : 'Add to Favourites'}
      </span>
    </button>
  )
}