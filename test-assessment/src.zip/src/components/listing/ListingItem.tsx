import { useEffect, useState } from 'react'
import type { CatItemDto } from '../../types/cat'
import apiRepository from '@/api/repository'
import type { FavouriteDto } from '@/types/favourites'
import ListItemFavourite from './ListItemFavourite'
import ListItemVoting from './ListItemVoting'

interface Props {
  item: CatItemDto
}

export default function ListItem({ item }: Props) {
  const { id: imageId, url } = item

  const [score, setScore] = useState<number>(0)
  const [voteLoading, setVoteLoading] = useState<boolean>(false)

  const [isFavourite, setIsFavourite] = useState<boolean>(false)
  const [favLoading, setFavLoading] = useState<boolean>(false)

  // Load initial data
  useEffect(() => {
    const fetchData = async () => {
      // Fetch votes
      setVoteLoading(true)
      try {
        const voteRes = await apiRepository.listing.getVotesByImage(imageId)
        const votes = voteRes.data
        const total = votes.reduce((acc, v) => acc + (v.value === 1 ? 1 : -1), 0)
        setScore(total)
      } catch (err) {
        console.error('Failed to fetch votes', err)
      } finally {
        setVoteLoading(false)
      }

      // Fetch favourites
      setFavLoading(true)
      try {
        const favRes = await apiRepository.listing.getFavourites()
        const favourites: FavouriteDto[] = favRes.data
        const match = favourites.find((f) => f.image_id === imageId)
        setIsFavourite(!!match)
      } catch (err) {
        console.error('Failed to fetch favourites', err)
      } finally {
        setFavLoading(false)
      }
    }

    fetchData()
  }, [imageId])

  const handleUpvote = async () => {
    if (voteLoading) return
    setVoteLoading(true)
    try {
      await apiRepository.listing.voteImage(imageId, 1)
      const voteRes = await apiRepository.listing.getVotesByImage(imageId)
      const votes = voteRes.data
      const total = votes.reduce((acc, v) => acc + (v.value === 1 ? 1 : -1), 0)
      setScore(total)
    } catch (err) {
      console.error('Failed to upvote', err)
    } finally {
      setVoteLoading(false)
    }
  }

  const handleDownvote = async () => {
    if (voteLoading) return
    setVoteLoading(true)
    try {
      await apiRepository.listing.voteImage(imageId, 0)
      const voteRes = await apiRepository.listing.getVotesByImage(imageId)
      const votes = voteRes.data
      const total = votes.reduce((acc, v) => acc + (v.value === 1 ? 1 : -1), 0)
      setScore(total)
    } catch (err) {
      console.error('Failed to downvote', err)
    } finally {
      setVoteLoading(false)
    }
  }

  const handleToggleFavourite = async () => {
    if (favLoading) return
    setFavLoading(true)
    try {
      const favRes = await apiRepository.listing.getFavourites()
      const favourites: FavouriteDto[] = favRes.data
      const match = favourites.find((f) => f.image_id === imageId)
      if (match) {
        // Remove favourite
        await apiRepository.listing.removeFromFavourites(match.id)
        setIsFavourite(false)
      } else {
        // Add favourite
        const addRes = await apiRepository.listing.addToFavourites(imageId)
        const newFav: FavouriteDto = addRes.data
        setIsFavourite(true)
      }
    } catch (err) {
      console.error('Failed to toggle favourite', err)
    } finally {
      setFavLoading(false)
    }
  }

  return (
    <div className="bg-white shadow-md rounded-lg p-4 mb-4">
      <img src={url} alt={`Cat ${imageId}`} className="w-full h-auto rounded-lg mb-2" />
      <div className="flex items-center justify-between">
        <ListItemFavourite
          isFavourite={isFavourite}
          loading={favLoading}
          onToggleFavourite={handleToggleFavourite}
        />
        <ListItemVoting
          score={score}
          loading={voteLoading}
          onUpvote={handleUpvote}
          onDownvote={handleDownvote}
        />
      </div>
    </div>
  )
}
